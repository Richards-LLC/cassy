# cas-98ba independent loopback terminal driver

Status: static handoff. Baseline is **NOT EXERCISED** for both rejection cases.
No candidate, push-rendering or doctor-rendering PASS is claimed. The supervisor
closed the prowl launch budget; do not rerun the installed baseline.

Target: `factory/gentle-spider-89-cas-98ba` at
`6baaeb8fdd1c43fe10d270a6fe52ca90e472b721`. This driver did not edit, build or push
that branch. The driver's author did not implement the change.

## Run the candidate on Linux (soundwave)

Extract this archive into `/tmp/cas-98ba-loopback`. Set `CANDIDATE_BIN` to the
absolute executable path of root's candidate built from the target above.

```bash
bash /tmp/cas-98ba-loopback/run.sh --bin "${CANDIDATE_BIN:?set the absolute candidate binary path}"
```

The driver requires `python3`, `unshare`, `ip`, and util-linux `script`. It
re-execs itself in **one `unshare -rn` namespace**, brings up `lo`, verifies the
namespace changed and that `lo` is its only interface, and starts both the stub
and every cas command there. It refuses an unconfined fallback if unshare is
unavailable or denied. PTY capture uses `script -qec`. Linux execution is
**NOT VERIFIED**; only syntax checks were authorized on prowl.

## Run the candidate on macOS

```bash
bash /Users/pippenz/.cas/artifacts/cassy-ee10031b42e3c2024023c076dfb2edd8118e39b8baee6f0832367b9e8ef4c205/cas-98ba/loopback/run.sh --bin "${CANDIDATE_BIN:?set the absolute candidate binary path}"
```

macOS requires `/usr/bin/script` and `/usr/bin/sandbox-exec`. The command order
is `script -q <capture> sandbox-exec -f <profile> ... cas ...`, placing the cas
process **inside the PTY and sandbox**. The profile permits native runtime
reads, denies writes outside the exact canonical temporary root and terminal
devices, denies the real account/profile paths, and allows network access only
to the stub's loopback port. Unix sockets remain denied. The native version
preflight runs once per driver invocation before any setup; a failed preflight
records Sandbox diagnostics and stops. Other OSes are refused.

`--bin` is mandatory; there is no PATH/default-binary fallback. The driver has
no external endpoint option and rejects anything except literal
`http://127.0.0.1:<ephemeral-port>`.

## Real data path and checks

- `cli/cloud.rs:3614-3770` runs the real queue planner and push.
- `cloud/syncer/push.rs:1183-1217` posts gzip JSON to `/api/sync/push`.
- `cloud/syncer/mod.rs:1059-1075` classifies `version_gate` as non-retryable and
  `timeout` as retryable. Those exact reason strings drive the two modes.
- The stub returns HTTP 200 with top-level row verdicts
  `{entity_type,id,outcome:"rejected",reason}` plus matching per-entity skipped
  counts, matching the real path exercised by `syncer/tests.rs:2892`.
- The stdlib-only stub never forwards requests. Every request is saved to
  `requests.jsonl`; Authorization is redacted. Unexpected endpoints stop the
  driver. It also serves the real scoped startup `GET /api/sync/pull` with empty
  arrays: `mcp/server/runtime.rs:89-136` performs this startup read independently
  of periodic auto-sync settings.
- Each case uses a fresh system `mkdtemp` root resolved with `realpath`, outside
  real `~/.cas`. Temp HOME, project, DB, logs and captures live there. Only after
  all sandboxed children exit does the controller copy evidence to `runs/<case>`
  and remove the exact directory it created. It never reads or edits a real
  account's `.cas`, cas.db or credentials.
- A constructed environment clears caller credentials, proxy and factory
  identity. The dummy loopback cloud config exists **before seeding**.
  Project `[cloud] auto_sync=false` and `pull_on_start=false` are set, and code
  indexing is disabled. The startup read mentioned above is served locally.
- The real `<bin> init` initializes storage. A temporary `<bin> serve` stdio
  MCP process calls `rule.create`, then exits. There is no hand-written SQL or
  queue insertion. A real `cloud push --dry-run --json` must show at least one
  pending row before terminal checks run.
- `cloud push` and `doctor` execute in native PTYs. Non-retryable checks require
  the push summary to omit generic `run cas cloud queue --retry` and doctor to
  include `Run \`cas cloud push\` to deliver other pending work; resolve the
  rejection-specific blockers below before retrying their rows`. The retryable
  case must retain the retry advice on both surfaces.
- One PASS/FAIL line per case and a summary are printed. Final raw transcripts,
  command exits, HTTP JSONL, and result JSON are retained. Baseline mode permits
  the known old non-retryable failure; candidate mode exits zero only if both
  rendering cases pass. Infrastructure/isolation failures exit 2 and stop.

## Baseline evidence and static corrections

The allowed before run did not reach either push/doctor case:

1. `preflight-syntax*`: SBPL rejected numeric IP syntax before executing cas.
   The profile now uses SBPL `localhost:<port>` while the HTTP client/stub are
   restricted to numeric `127.0.0.1`.
2. `baseline-attempt1*`: deny-default profile aborted `cas --version` with
   SIGABRT and no stderr. No cas setup or mutations ran.
3. `baseline-attempt2*`: allow-default preflight reported
   `cas 3.62.0 (74ae311 2026-10-17)`, then init could not open SQLite beneath the
   protected real `~/.cas/artifacts`. The driver now uses system temporary
   directories and copies evidence back after children exit.
4. `baseline-driver.log`, `baseline-3.62.txt`, `baseline-results.json`, and
   `runs/cas98ba-non-retryable-90_c_2u1/`: the final authorized attempt passed
   version/init and created a real MCP memory, but its dry-run queue was empty.
   The driver had written dummy login config **after** seeding, so
   `store/detect.rs:425-435` never installed its syncing store wrapper. It
   stopped before push/doctor, with zero HTTP requests. Final static correction
   writes login config before the new `rule.create` seed and disables periodic
   sync. This correction has **not been executed**.

Both cases therefore remain **NOT EXERCISED**, not product failures. Empty
Sandbox query output in `sandbox-denials.log` is not proof that no denied call
occurred. The initial failed infrastructure launches and final copied fixture
records are preserved, and no installed-binary launch budget remains.

## Isolation limits

- macOS intentionally permits OS/native-runtime reads. It denies real account
  paths (`~/.cas`, `~/.config`, Keychains, `.ssh`, `.codex`, `.claude*`) and
  cloud.json files outside the exact temp root. Its OS loopback matcher can
  include IPv6 localhost, although all actual configured URLs and the stub
  bind use IPv4 `127.0.0.1` only.
- Linux's `unshare -rn` supplies network isolation, not a filesystem mount
  sandbox. The constructed HOME/config environment prevents intentional host
  credential discovery by this CLI, but a hostile binary could read host
  files. Run only the reviewed candidate, preferably in root's disposable QA
  checkout/container. Do not interpret temp HOME alone as filesystem isolation.
- Captured explicit permission/sandbox errors stop execution. Silent swallowed
  OS denials cannot be inferred from a successful command; request logs prove
  only traffic actually received by the stub.
- No Cargo command, real Cloud call, existing daemon/hub restart, or branch
  edit is part of this handoff. The temporary MCP server's embedded maintenance
  thread is terminated with that server; no host daemon is restarted.

## Static proof

`python3 -m py_compile loopback_cloud.py run_driver.py` and `bash -n run.sh`
both passed with exit 0 after the final edits. `SHA256SUMS` covers the final stub, driver, wrapper,
README, baseline transcript/result, and driver log. Verify after extraction
with `sha256sum -c SHA256SUMS` on Linux or `shasum -a 256 -c SHA256SUMS` on macOS.
