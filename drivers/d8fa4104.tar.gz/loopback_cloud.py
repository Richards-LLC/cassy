#!/usr/bin/env python3
"""One-shot, stdlib-only Cloud push stand-in. No upstream forwarding."""
import argparse
import gzip
import http.server
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

# 6baaeb8fd, cas-cli/src/cloud/syncer/mod.rs:1059-1075.
# version_gate is absent from the retry allowlist; timeout is present.
REASONS = {"non-retryable": "version_gate", "retryable": "timeout"}


class CloudStub(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, mode, log_path, bind="127.0.0.1"):
        if bind != "127.0.0.1":
            raise ValueError("only the literal loopback address 127.0.0.1 is allowed")
        self.reason = REASONS[mode]
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_path.touch(exist_ok=True)
        self.records = []
        self.violation = None
        self.lock = threading.Lock()
        super().__init__((bind, 0), Handler)

    @property
    def endpoint(self):
        return f"http://127.0.0.1:{self.server_port}"


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def handle_request(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length", "0")))
        error = None
        try:
            decoded = gzip.decompress(raw) if self.headers.get("Content-Encoding") == "gzip" else raw
            body = json.loads(decoded) if decoded else None
        except (ValueError, OSError) as exc:
            body, error = None, type(exc).__name__
        target = urlsplit(self.path)
        push = self.command == "POST" and target.path == "/api/sync/push" and not target.query and isinstance(body, dict)
        # MCP startup_cloud_pull (runtime.rs:89-136) may still do its initial
        # read even with periodic auto-sync disabled. Return no remote rows.
        pull = self.command == "GET" and target.path == "/api/sync/pull" and parse_qs(target.query).get("project_id") == ["cas-98ba-loopback"]
        valid = self.client_address[0] == "127.0.0.1" and (push or pull)
        response = {"canonical_id": "cas-98ba-loopback", "rows": []}
        if pull:
            response.update({key: [] for key in ["entries", "tasks", "rules", "skills", "sessions", "specs", "events", "prompts", "file_changes", "commit_links", "knowledge_pages", "task_dependencies"]})
            response["pulled_at"] = datetime.now(timezone.utc).isoformat()
        if valid and push:
            for key, values in body.items():
                if not isinstance(values, list):
                    continue
                rows = [row for row in values if isinstance(row, dict) and isinstance(row.get("id"), str)]
                if rows:
                    response[key] = {"inserted": 0, "updated": 0, "skipped": len(rows)}
                    response["rows"].extend({"entity_type": key, "id": row["id"], "outcome": "rejected", "reason": self.server.reason} for row in rows)
        record = {
            "at": datetime.now(timezone.utc).isoformat(), "peer": self.client_address[0],
            "method": self.command, "path": self.path,
            "headers": {key: ("[redacted]" if key.lower() == "authorization" else value) for key, value in self.headers.items()},
            "body": body, "decode_error": error,
            "status": 200 if valid else 400, "response": response,
        }
        with self.server.lock:
            self.server.records.append(record)
            with self.server.log_path.open("a") as stream:
                stream.write(json.dumps(record, sort_keys=True) + "\n")
            if not valid:
                self.server.violation = f"unexpected request: {self.command} {self.path} ({error})"
        encoded = json.dumps(response if valid else {"error": "unexpected loopback request"}).encode()
        self.send_response(200 if valid else 400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    do_POST = handle_request
    do_GET = handle_request
    do_PUT = handle_request
    do_PATCH = handle_request
    do_DELETE = handle_request
    do_HEAD = handle_request
    do_OPTIONS = handle_request


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=REASONS)
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--bind", default="127.0.0.1")
    args = parser.parse_args()
    server = CloudStub(args.mode, args.log, args.bind)
    print(server.endpoint, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
