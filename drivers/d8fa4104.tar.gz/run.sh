#!/usr/bin/env bash
set -euo pipefail
driver_dir="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$driver_dir/run_driver.py" "$@"
