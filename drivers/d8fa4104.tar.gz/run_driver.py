#!/usr/bin/env python3
"""Isolated macOS native-PTY evidence for cas-98ba; never runs Cargo."""
import argparse
import hashlib
import json
import os
import platform
import queue
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from urllib.parse import urlsplit

from loopback_cloud import CloudStub, REASONS

ROOT = Path(__file__).resolve().parent
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
BLOCKED_REMEDY = "Run `cas cloud push` to deliver other pending work; resolve the rejection-specific blockers below before retrying their rows"
PROJECT_CONFIG = '[project]\ncanonical_id = "cas-98ba-loopback"\n[sync]\nenabled = true\n[cloud]\nauto_sync = false\npull_on_start = false\n[code]\nenabled = false\n'


def loopback_only(endpoint):
    parsed = urlsplit(endpoint)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or not parsed.port or parsed.username or parsed.password or parsed.path:
        raise ValueError("refusing endpoint outside literal http://127.0.0.1:<port>")


def plain(text):
    return ANSI.sub("", text).replace("\r", "")


def isolated_env(case, endpoint):
    loopback_only(endpoint)
    home, project = case / "home", case / "project"
    for path in [home / ".cas", home / ".config", home / ".cache", home / ".local/share", home / ".codex", home / ".claude", project / ".cas"]:
        path.mkdir(parents=True, exist_ok=True)
    # Deliberately construct an environment, rather than copy credentials,
    # factory identity, proxy variables or harness settings from the caller.
    env = {
        "HOME": str(home), "CFFIXED_USER_HOME": str(home),
        "XDG_CONFIG_HOME": str(home / ".config"), "XDG_CACHE_HOME": str(home / ".cache"),
        "XDG_DATA_HOME": str(home / ".local/share"), "TMPDIR": str(case) + "/",
        "CODEX_HOME": str(home / ".codex"), "CLAUDE_CONFIG_DIR": str(home / ".claude"),
        "CAS_ROOT": str(project / ".cas"), "CAS_USER_CLOUD_JSON": str(home / ".cas/cloud.json"),
        "CAS_CLOUD_ENDPOINT": endpoint, "CAS_TELEMETRY": "0",
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "TERM": "xterm-256color",
        "LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8", "COLUMNS": "120", "LINES": "40",
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(home / ".gitconfig"),
        "GIT_CEILING_DIRECTORIES": str(case),
    }
    (home / ".gitconfig").write_text("")
    (project / ".cas/config.toml").write_text(PROJECT_CONFIG)
    return env, project


def sandbox(case, binary, port):
    if platform.system() == "Linux":
        return []  # The whole driver, including its stub, is already in netns.
    # Permit native runtime reads; explicitly deny real account/profile data.
    # The complete temporary case is outside the real ~/.cas, not an exception
    # beneath it. Only the unsandboxed controller copies evidence back later.
    profile = case / "isolation.sb"
    q = lambda value: json.dumps(str(value))
    real_home = Path.home()
    protected = [real_home / name for name in [".cas", ".config", "Library/Keychains", ".ssh", ".codex"]]
    protected_rules = " ".join(f"(subpath {q(path)})" for path in protected)
    claude = json.dumps(re.escape(str(real_home)) + r"/[.]claude[^/]*(/.*)?$")
    profile.write_text(f'''(version 1)
(allow default)
(deny network*)
(allow network* (remote ip "localhost:{port}"))
(deny file-write* (require-all
  (require-not (subpath {q(case)}))
  (require-not (literal "/dev/null"))
  (require-not (literal "/dev/dtracehelper"))
  (require-not (regex #"/dev/tty.*"))))
(deny file-read* (require-any {protected_rules} (regex #{claude})))
(deny file-read* (require-all
  (regex #".*/(project[.])?cloud[.]json$")
  (require-not (subpath {q(case)}))))
''')
    return ["/usr/bin/sandbox-exec", "-f", str(profile)]


def check_output(text):
    if any(marker in text.lower() for marker in ["operation not permitted", "sandbox initialization failed", "permission denied"]):
        raise RuntimeError("isolation denial detected; stop rather than relax the sandbox")


def command(prefix, binary, args, project, env, output):
    result = subprocess.run(prefix + [str(binary)] + args, cwd=project, env=env,
                            capture_output=True, text=True, timeout=90)
    text = result.stdout + result.stderr
    output.write_text(text)
    check_output(text)
    if result.returncode:
        raise RuntimeError(f"setup command {args} exited {result.returncode}; see {output}")
    return result.stdout


def seed(prefix, binary, project, env, case):
    """Use real CLI stdio MCP; no SQLite/queue fabrication or live service."""
    with (case / "seed.stderr.txt").open("w") as stderr:
        proc = subprocess.Popen(prefix + [str(binary), "serve"], cwd=project, env=env,
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)
        replies = queue.Queue()
        def read():
            for line in proc.stdout:
                replies.put(line)
        thread = threading.Thread(target=read, daemon=True)
        thread.start()
        transcript = []
        def send(value):
            proc.stdin.write(json.dumps(value) + "\n")
            proc.stdin.flush()
        def receive(request_id):
            while True:
                line = replies.get(timeout=45)
                transcript.append(line)
                message = json.loads(line)
                if message.get("id") == request_id:
                    if message.get("error") or message.get("result", {}).get("isError"):
                        raise RuntimeError(f"seed MCP failed: {message}")
                    return message["result"]
        try:
            send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "cas-98ba-loopback", "version": "1"}}})
            receive(1)
            send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            send({"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "rule", "arguments": {"action": "create", "scope": "project", "content": "Isolated cas-98ba terminal evidence fixture.", "tags": "cas-98ba-loopback"}}})
            receive(2)
        finally:
            proc.stdin.close()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.terminate()
                proc.wait(timeout=5)
            (case / "seed.mcp.jsonl").write_text("".join(transcript))
    check_output((case / "seed.stderr.txt").read_text())


def native_pty(prefix, binary, args, project, env, output):
    # script owns a real PTY; capture the CLI's native rendering, not a JSON
    # facsimile. Fixed shell program, arguments passed as positional values.
    status = output.with_suffix(".exit")
    shell = 'stty cols 120 rows 40; "$@"; result=$?; printf "%s\\n" "$result" > "$CAS_98BA_EXIT"; exit "$result"'
    env = dict(env, CAS_98BA_EXIT=str(status))
    if platform.system() == "Darwin":
        invocation = ["/usr/bin/script", "-q", str(output)] + prefix + ["/bin/sh", "-c", shell, "driver", str(binary)] + args
    else:
        invocation = [shutil.which("script"), "-qec", 'stty cols 120 rows 40; exec ' + shlex.join([str(binary)] + args), str(output)]
    result = subprocess.run(invocation,
                            cwd=project, env=env, capture_output=True, text=True, timeout=90)
    text = output.read_text(errors="replace") if output.exists() else result.stdout + result.stderr
    check_output(text + result.stderr)
    if platform.system() == "Linux":
        status.write_text(str(result.returncode) + "\n")
    if not status.exists():
        raise RuntimeError(f"PTY command did not record an exit status: {result.stderr}")
    return text, int(status.read_text().strip())


def run_case(mode, binary, run_root, baseline=False, version=None):
    # Equivalent to mktemp -d "$TMPDIR/cas98ba.XXXXXX" followed by realpath.
    # Never put the sandboxed project below the protected ~/.cas/artifacts.
    case = Path(tempfile.mkdtemp(prefix=f"cas98ba-{mode}-")).resolve()
    temp_parent = Path(tempfile.gettempdir()).resolve()
    if case.parent != temp_parent or not case.name.startswith("cas98ba-"):
        raise RuntimeError("temporary root validation failed; refusing execution/cleanup")
    archive = run_root / case.name
    stub = CloudStub(mode, case / "requests.jsonl")
    serving = threading.Thread(target=stub.serve_forever, daemon=True)
    serving.start()
    try:
        env, project = isolated_env(case, stub.endpoint)
        prefix = sandbox(case, binary, stub.server_port)
        if version is None:
            try:
                version = command(prefix, binary, ["--version"], project, env, case / "version.txt").strip()
            except Exception:
                if platform.system() == "Darwin":
                    denial = subprocess.run(["/usr/bin/log", "show", "--last", "30m", "--style", "compact", "--predicate", 'sender == "Sandbox"'], env=env, capture_output=True, text=True, timeout=30)
                    (case / "sandbox-denials.log").write_text(denial.stdout + denial.stderr)
                raise
        else:
            (case / "version.txt").write_text(version + "\n(same binary, preflight completed earlier in this driver invocation)\n")
        if baseline and not re.search(r"\b3\.62\.0\b", version):
            raise RuntimeError(f"installed baseline is not 3.62.0: {version}")
        command(prefix, binary, ["init", "--yes", "--no-integrations"], project, env, case / "init.txt")
        (project / ".cas/config.toml").write_text(PROJECT_CONFIG)
        # Login must exist before opening the real syncing rule store.
        # Periodic push is disabled above; no queue rows are fabricated.
        config = {"endpoint": stub.endpoint, "token": "loopback-dummy-token", "team_auto_promote": False}
        (project / ".cas/cloud.json").write_text(json.dumps(config))
        seed(prefix, binary, project, env, case)
        if stub.violation or any(record["method"] != "GET" for record in stub.records):
            raise RuntimeError("unexpected mutation/request during seeding; stopping")
        # The real CLI dry run must prove the real rule write was queued.
        plan = json.loads(command(prefix, binary, ["cloud", "push", "--dry-run", "--json"], project, env, case / "pending-plan.json"))
        if plan.get("plan", {}).get("total_matching", 0) < 1:
            raise RuntimeError(f"no pending CLI-created row in {case / 'pending-plan.json'}")
        push, push_exit = native_pty(prefix, binary, ["cloud", "push"], project, env, case / "push.pty.txt")
        doctor, doctor_exit = native_pty(prefix, binary, ["doctor"], project, env, case / "doctor.pty.txt")
        if stub.violation:
            raise RuntimeError(stub.violation)
        if not any(record["response"]["rows"] for record in stub.records):
            raise RuntimeError("push did not send any fixture row to the stub")
        push_text = plain(push)
        doctor_text = " ".join(plain(doctor).split())
        advice = "run cas cloud queue --retry" in push_text.lower()
        summary_present = "Push incomplete" in push_text
        if mode == "non-retryable":
            passed = summary_present and not advice and BLOCKED_REMEDY in doctor_text
        else:
            passed = summary_present and advice and "Run `cas cloud queue --retry`, then `cas cloud push`" in doctor_text
        result = {"mode": mode, "reason": REASONS[mode], "pass": passed, "case_dir": str(archive), "temporary_root": str(case), "endpoint": stub.endpoint, "version": version,
                  "push_exit": push_exit, "doctor_exit": doctor_exit, "push_retry_advice": advice, "request_count": len(stub.records)}
        (case / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        return result, push, doctor
    except Exception as exc:
        if platform.system() == "Darwin" and not (case / "sandbox-denials.log").exists():
            denial = subprocess.run(["/usr/bin/log", "show", "--last", "30m", "--style", "compact", "--predicate", 'sender == "Sandbox"'], env=env, capture_output=True, text=True, timeout=30)
            (case / "sandbox-denials.log").write_text(denial.stdout + denial.stderr)
        raise RuntimeError(f"{exc}; archived evidence: {archive}") from exc
    finally:
        stub.shutdown()
        stub.server_close()
        serving.join(timeout=5)
        archive.mkdir(parents=True, exist_ok=False)
        for source in case.iterdir():
            if source.is_file():
                shutil.copy2(source, archive / source.name)
        # Remove only the exact private directory returned by mkdtemp above.
        shutil.rmtree(case)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bin", required=True, type=Path, help="explicit installed or candidate cas binary")
    parser.add_argument("--baseline", action="store_true", help="record the one installed-3.62 before run; expected non-retryable failure")
    parser.add_argument("--baseline-attempt", type=int, choices=[1, 2, 3], default=1, help="explicit supervisor-authorized preflight attempt; never auto-retried")
    parser.add_argument("--netns-parent", help=argparse.SUPPRESS)
    args = parser.parse_args()
    binary = args.bin.expanduser().resolve(strict=True)
    if platform.system() == "Linux":
        if not shutil.which("unshare") or not shutil.which("ip") or not shutil.which("script"):
            parser.error("Linux requires unshare, ip and script; refusing unconfined fallback")
        if not args.netns_parent:
            parent_ns = os.readlink("/proc/self/ns/net")
            bootstrap = ROOT / "linux-bootstrap-home"
            bootstrap.mkdir(exist_ok=True)
            child_env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(bootstrap), "LANG": "C.UTF-8"}
            invocation = [shutil.which("unshare"), "-rn", "/bin/sh", "-c", 'ip link set dev lo up || exit 125; exec "$@"', "driver", sys.executable, str(Path(__file__).resolve())] + sys.argv[1:] + ["--netns-parent", parent_ns]
            return subprocess.run(invocation, env=child_env, timeout=300).returncode
        import socket
        if os.readlink("/proc/self/ns/net") == args.netns_parent or [name for _, name in socket.if_nameindex()] != ["lo"]:
            parser.error("network namespace isolation not established; refusing to execute cas")
    elif platform.system() != "Darwin" or not Path("/usr/bin/sandbox-exec").exists():
        parser.error("only macOS sandbox-exec or Linux unshare are supported")
    if not binary.is_file() or not os.access(binary, os.X_OK):
        parser.error("--bin must name an executable regular file")
    runs = ROOT / "runs"
    runs.mkdir(exist_ok=True)
    result_path = ROOT / ("baseline-results.json" if args.baseline else "candidate-results.json")
    capture = ROOT / ("baseline-3.62.txt" if args.baseline else "candidate-terminal.txt")
    started = ROOT / f"baseline-attempt{args.baseline_attempt}-started.json"
    if args.baseline and (result_path.exists() or capture.exists() or started.exists()):
        parser.error("baseline already exists; refusing a repeated before run")
    if args.baseline:
        started.write_text(json.dumps({"binary": str(binary), "pid": os.getpid()}) + "\n")
    results, captures = [], []
    try:
        version = None
        for mode in REASONS:
            result, push, doctor = run_case(mode, binary, runs, args.baseline, version)
            version = result["version"]
            results.append(result)
            captures.append(f"=== {mode}: cloud push ===\n{push}\n=== {mode}: doctor ===\n{doctor}\n")
            print(f"{'PASS' if result['pass'] else 'FAIL'} {mode}: reason={result['reason']}; push retry advice={result['push_retry_advice']}; evidence={result['case_dir']}", flush=True)
        metadata = {"binary": str(binary), "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(), "baseline": args.baseline, "cases": results}
        result_path.write_text(json.dumps(metadata, indent=2) + "\n")
        capture.write_text("\n".join(captures))
        passed = sum(result["pass"] for result in results)
        print(f"SUMMARY {passed}/{len(results)} cases pass; native captures: {capture}")
        expected_before = args.baseline and not results[0]["pass"] and results[0]["push_retry_advice"] and results[1]["pass"]
        return 0 if passed == len(results) or expected_before else 1
    except Exception as exc:
        capture.write_text("\n".join(captures) + f"\nSTOP: {type(exc).__name__}: {exc}\n")
        for mode in REASONS:
            if not any(result["mode"] == mode for result in results):
                print(f"FAIL {mode}: NOT RUN; isolation/setup stopped: {type(exc).__name__}: {exc}", flush=True)
        result_path.write_text(json.dumps({"binary": str(binary), "baseline": args.baseline, "error": str(exc), "completed_cases": results}, indent=2) + "\n")
        print("SUMMARY stopped; no isolation relaxation or automatic rerun", flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
