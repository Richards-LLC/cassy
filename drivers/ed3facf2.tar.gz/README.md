# cas-d16e independent loopback MCP driver

Source inspected read-only:61ca6e995ff85b1d5d3029ae484545fc4d49a01d.
No candidate branch edit/push or Cargo. Candidate NOT EXERCISED here.

## Linux candidate command

Extract the five-file handoff into a dedicated directory, then from that directory:

```bash
python3 -I driver.py --bin /ABSOLUTE/PATH/TO/CANDIDATE/cas --out "$PWD/runs/candidate-61ca6e995"
```

Replace only the binary path; output must be a NEW subdirectory of the driver
location. --bin and --out are mandatory; no PATH/installed-binary fallback.
Requirements: Python3 stdlib, /usr/bin/git, unshare with unprivileged user+network
namespace support, and ip. No credentials are needed. Exit0 means5/5 contract
PASS; exit1 is contract failure; exit2/setup or unshare refusal is NOT EXERCISED.

Linux outer driver re-execs itself with `unshare -rn -- <python> -I ...` and a
cleared environment. The child checks its network namespace differs from its
parent, requires the only interface to be lo, brings lo up using ip, then starts
BOTH Cloud stub and cas inside that namespace. It never falls back to host
network if unshare/IP fails. --netns-child is internal and cannot bypass the
namespace/interface checks. This Linux path is STATIC-CHECKED ONLY on macOS;
root must establish the executed result. Other OSes are refused.

## Handler and assertions

Real paths read from pattern_ops.rs:POST/api/patterns (:31), GET/api/patterns
(:65). The driver uses actual `<bin> serve` stdio MCP initialize/initialized,
then one pattern.create and one pattern.list call for each case. No decoder
function is called directly.

| mode | stub reply | required result |
| --- | --- | --- |
| bare |201 persisted row/id|created persisted id|
| wrapped |201 legacy pattern wrapper/id|created persisted id|
| missing_id_header |201 JSON/no id + x-request-id|uncertain, exact request id|
| missing_id_no_headers |201 JSON/no id, no correlation headers|uncertain, local UUIDv4|
| non_json |201 text, no correlation headers|uncertain, local UUIDv4|

All uncertain errors must carry outcome=uncertain,http_status=201,
retry_safe=false, no-blind-retry and pattern action=list guidance. A real list
call must find the persisted id after every create. No-header means no
correlation response headers; HTTP framing/auth headers still exist. All
request bodies are public fixture content; token is a dummy, redacted in logs.
Exactly1 POST per mode and5 POSTs total after serve exits are asserted. There
is no create retry. Each mode prints one PASS/FAIL line, then a summary.

## Config, evidence and cleanup

Child env is rebuilt from scratch: temp HOME, TMPDIR, XDG dirs, no inherited
CAS factory identity, real tokens, SSH agent or proxy. Real config mechanisms:
CAS_CLOUD_ENDPOINT (cloud/config.rs:1033), CAS_USER_CLOUD_JSON (:1061), explicit
project/user cloud.json containing dummy token. The stub binds127.0.0.1:0;
URL validation accepts ONLY http://127.0.0.1:<port>, no userinfo/path/query.
Periodic cloud/code work and telemetry are disabled in temp config; unavoidable
startup GETs hit only the stub and are logged/404. Startup proxy env is absent.

Runtime root is mkdtemp(casd16e.*) under canonical OS TMPDIR, OUTSIDE real
~/.cas. Real cas init --yes --no-integrations creates its own store. All MCP
requests/replies (verbatim response bytes), stderr, HTTP JSONL, metadata and
results are written into that temp root. After serve is reaped, root-level
receipts are copied to --out; only that exact allocated temp root is removed.
No real cas.db/credential file is read. Real daemon/hub is never restarted.

macOS mode uses sandbox-exec allow-default plus explicit network deny except
localhost:stubport (macOS requires localhost spelling; endpoint/bind is127.0.0.1),
write deny except temp root/dev null/dev tty/dev dtracehelper, and protected
read denies for real ~/.cas, ~/.config, Keychains, SSH, Codex, Claude account
roots, gabber/cassy .cas and outside-temp Cloud configs. Unix sockets are
blocked; a denied temporary embedded-daemon socket is logged without widening.
Keep the driver in its requested ~/.cas artifact location for this macOS mode.

Linux unshare isolates NETWORK only, not filesystem or filesystem-addressed
Unix sockets. Temp HOME/CAS and cleared env steer the trusted CLI away from
real user data, but this is NOT a Linux filesystem sandbox or syscall audit.
Silently swallowed denied accesses on macOS cannot be observed by Python.
Do not claim stricter isolation than these mechanisms provide.

## Baseline history — no candidate approval

Original baseline preflight: sandbox numeric-host syntax rejected, then
--version SIGABRT. Retry1 allow-default: --version confirmed
cas3.62.0(74ae3112026-10-17); git-init denied protected ~/.cas ancestor.
Those runs are NOT EXERCISED and preserved in baseline-run, baseline-run2,
baseline-run3 with Sandbox log query (no matching records).

The second authorized retry completed BEFORE supervisor stop538572 arrived:
supplemental runs/baseline-3.62 and baseline-retry2.txt show real MCP:
bareFAIL/wrappedPASS/missing_id_headerFAIL/missing_id_no_headersFAIL/non_jsonFAIL,
exactly5POSTs and list reconciliationPASS for all. Bare/missing-id got old
'Missing pattern in response'; non-JSON got old parse error. This is retained
raw history, not candidate QA or a replacement for root's requested candidate
execution. All prowl launches are now STOPPED. No candidate was run here.

Static receipts: python3 -m py_compile cloud_stub.py driver.py; bash -n run.sh.
SHA256SUMS covers the four executable/document inputs. The manifest's own
SHA is returned separately by the artifact publisher. Driver code is frozen.
