"""Local Cloud response-contract stub; Python 3 standard library only."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

MODES = ('bare', 'wrapped', 'missing_id_header', 'missing_id_no_headers', 'non_json')
REQUEST_ID = 'cas-d16e-loopback-request'


def validate_endpoint(endpoint):
    p = urlsplit(endpoint)
    if (p.scheme != 'http' or p.hostname != '127.0.0.1' or not p.port
            or p.username or p.password or p.path or p.query or p.fragment):
        raise ValueError('REFUSED: endpoint must be http://127.0.0.1:<port>')
    return endpoint


class CloudStub(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, log_path):
        super().__init__(('127.0.0.1', 0), Handler)
        self.log_path = Path(log_path)
        self.log_path.write_bytes(b'')
        self.lock = threading.Lock()
        self.mode = 'bare'
        self.requests = []
        self.rows = []
        self.thread = threading.Thread(target=self.serve_forever, daemon=True)
        self.endpoint = validate_endpoint('http://127.0.0.1:%s' % self.server_port)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.shutdown()
        self.server_close()
        self.thread.join(timeout=3)


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    def do_GET(self):
        self.respond()

    def do_POST(self):
        self.respond()

    def do_PUT(self):
        self.respond()

    def do_PATCH(self):
        self.respond()

    def do_DELETE(self):
        self.respond()

    def respond(self):
        raw = self.rfile.read(int(self.headers.get('Content-Length', '0')))
        try:
            body = json.loads(raw) if raw else None
        except ValueError:
            body = raw.decode('utf-8', errors='replace')
        with self.server.lock:
            mode = self.server.mode
            row_id = 'pat-loopback-' + mode
            row = {'id': row_id, 'content': 'Public loopback fixture ' + mode,
                   'category': 'general', 'priority': 1, 'status': 'active',
                   'propagation': 'all_projects', 'propagation_tags': ['cas-d16e-loopback']}
            status, extra = 200, {}
            if self.command == 'POST' and self.path == '/api/patterns':
                self.server.rows.append(row)
                status = 201
                if mode == 'bare':
                    response = row
                elif mode == 'wrapped':
                    response = {'pattern': row}
                elif mode in ('missing_id_header', 'missing_id_no_headers'):
                    response = {'content': row['content']}
                    if mode == 'missing_id_header':
                        extra['x-request-id'] = REQUEST_ID
                elif mode == 'non_json':
                    response = None
                else:
                    raise ValueError('unknown response mode')
            elif self.command == 'GET' and urlsplit(self.path).path == '/api/patterns':
                response = {'patterns': list(self.server.rows)}
            else:
                # Startup sync may GET another loopback path. It never reaches Cloud.
                status, response = 404, {'error': 'No loopback route', 'path': self.path}
            payload = b'Persisted; unreadable result' if response is None else json.dumps(response).encode()
            entry = {'at': time.time(), 'mode': mode, 'method': self.command,
                     'path': self.path, 'headers': {k: ('[dummy-token-redacted]' if k.lower() == 'authorization' else v)
                                                  for k, v in self.headers.items()},
                     'body': body, 'response_status': status,
                     'response_headers': extra, 'response_body': payload.decode()}
            self.server.requests.append(entry)
            with self.server.log_path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(entry) + '\n')
        self.send_response_only(status)
        self.send_header('Content-Type', 'text/plain' if response is None else 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Connection', 'close')
        for k, v in extra.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(payload)
        self.close_connection = True
