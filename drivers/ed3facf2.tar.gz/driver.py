#!/usr/bin/env python3
"""Independent real `cas serve` MCP evidence; never defaults to an installed binary."""
import argparse
import json
import os
from pathlib import Path
import platform
import queue
import re
import signal
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import uuid
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cloud_stub import CloudStub, MODES, REQUEST_ID, validate_endpoint

ROOT = Path(__file__).resolve().parent
SOURCE_SHA = '61ca6e995ff85b1d5d3029ae484545fc4d49a01d'
TOKEN = 'cas-d16e-loopback-dummy-token'


def child_env(root, endpoint):
    # Whitelist from scratch: no parent CAS identity, SSH agent, tokens, proxy or factory env.
    home = root / 'home'
    for p in (home, home / '.cas', root / 'tmp', home / '.config', home / '.cache'):
        p.mkdir(parents=True, exist_ok=True)
    return {'HOME': str(home), 'PATH': ('/Library/Developer/CommandLineTools/usr/bin:' if platform.system() == 'Darwin' else '') + '/usr/bin:/bin:/usr/sbin:/sbin',
            'TMPDIR': str(root / 'tmp'), 'XDG_CONFIG_HOME': str(home / '.config'),
            'XDG_CACHE_HOME': str(home / '.cache'), 'XDG_DATA_HOME': str(home / '.local/share'),
            'CAS_CLOUD_ENDPOINT': validate_endpoint(endpoint),
            'CAS_USER_CLOUD_JSON': str(home / '.cas/cloud.json'),
            'CAS_TELEMETRY': '0', 'CAS_SENTRY': '0', 'NO_COLOR': '1',
            'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
            'GIT_TERMINAL_PROMPT': '0'}


def verify_linux_namespace():
    """Never permit the hidden child path to execute on the host network."""
    if os.readlink('/proc/self/ns/net') == os.readlink('/proc/%s/ns/net' % os.getppid()):
        raise RuntimeError('REFUSED: Linux child did not enter a new network namespace')
    if {name for _, name in socket.if_nameindex()} != {'lo'}:
        raise RuntimeError('REFUSED: isolated namespace has interfaces other than lo')
    ip = shutil.which('ip', path='/usr/sbin:/usr/bin:/sbin:/bin')
    if not ip:
        raise RuntimeError('REFUSED: ip utility unavailable for namespace loopback setup')
    subprocess.run([ip, 'link', 'set', 'lo', 'up'], check=True, timeout=5,
                   env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin'})


def sandbox_profile(root, binary, endpoint):
    if platform.system() == 'Linux':
        # The whole driver, stub and child processes are already in one netns.
        verify_linux_namespace()
        return None
    if platform.system() != 'Darwin' or not Path('/usr/bin/sandbox-exec').is_file():
        raise RuntimeError('REFUSED: need macOS sandbox-exec or Linux unshare -rn')
    port = validate_endpoint(endpoint).rsplit(':', 1)[1]
    lit = lambda p: json.dumps(str(p))
    real_home = next(parent.parent for parent in ROOT.parents if parent.name == '.cas')
    protected = [real_home / name for name in ('.cas', '.config', 'Library/Keychains', '.ssh', '.codex')]
    protected += [real_home / 'Petrastella' / repo / '.cas' for repo in ('gabber', 'cassy')]
    deny_parts = ['(subpath %s)' % lit(path) for path in protected]
    deny_parts += ['(regex #%s)' % lit(re.escape(str(real_home)) + r'/\.claude[^/]*(/|$)'),
                   '(regex #%s)' % lit(r'/(gabber|cassy)/\.cas(/|$)'),
                   '(regex #%s)' % lit(r'/(project\.cloud\.json|\.cas/cloud\.json)$')]
    return '\n'.join([
        '(version 1)', '(allow default)',
        '(deny network*)',
        '(allow network* (remote ip "localhost:%s"))' % port,
        '(deny file-write* (require-all (require-not (subpath %s))' % lit(root),
        ' (require-not (literal "/dev/null")) (require-not (regex #"^/dev/tty"))',
        ' (require-not (literal "/dev/dtracehelper"))))',
        '(deny file-read* (require-all (require-any %s)' % ' '.join(deny_parts),
        ' (require-not (subpath %s))))' % lit(root),
    ]) + '\n'


def launch_command(binary, args, profile):
    if profile is None:
        if platform.system() != 'Linux':
            raise RuntimeError('REFUSED: no sandbox profile on this OS')
        return [str(binary)] + args
    return ['/usr/bin/sandbox-exec', '-f', str(profile), str(binary)] + args


def guarded(binary, args, profile, root, env, name):
    command = launch_command(binary, args, profile)
    started = time.time()
    proc = subprocess.Popen(command, cwd=root / 'project', env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = proc.communicate(timeout=40)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        stdout, stderr = proc.communicate(timeout=5)
    (root / (name + '.stdout')).write_bytes(stdout)
    (root / (name + '.stderr')).write_bytes(stderr)
    (root / (name + '.launch.json')).write_text(json.dumps({
        'pid':proc.pid, 'command':command, 'started_at':started, 'exit':proc.returncode}, indent=2)+'\n')
    if proc.returncode:
        raise RuntimeError('%s exited %s (pid %s); see %s.stderr' % (name, proc.returncode, proc.pid, name))
    return stdout.decode('utf-8', errors='replace').strip()


class MCP:
    def __init__(self, binary, profile, root, env):
        self.root = root
        self.stderr = (root / 'serve.stderr').open('wb')
        self.sent = (root / 'mcp-sent.jsonl').open('wb')
        self.received = (root / 'mcp-received.jsonl').open('wb')
        self.lines = queue.Queue()
        self.process = subprocess.Popen(launch_command(binary, ['serve'], profile),
                                        cwd=root / 'project', env=env, stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=self.stderr, start_new_session=True)
        def read():
            for line in self.process.stdout:
                self.received.write(line)
                self.received.flush()
                self.lines.put(line)
            self.lines.put(None)
        self.reader = threading.Thread(target=read, daemon=True)
        self.reader.start()

    def send(self, value):
        raw = json.dumps(value, separators=(',', ':')).encode() + b'\n'
        self.sent.write(raw)
        self.sent.flush()
        self.process.stdin.write(raw)
        self.process.stdin.flush()

    def call(self, request_id, method, params, filename):
        self.send({'jsonrpc': '2.0', 'id': request_id, 'method': method, 'params': params})
        deadline = time.monotonic() + 25
        while True:
            try:
                raw = self.lines.get(timeout=max(0, deadline - time.monotonic()))
            except queue.Empty:
                raise RuntimeError('MCP timeout: ' + method)
            if raw is None:
                raise RuntimeError('serve exited before reply to ' + method)
            response = json.loads(raw)
            if response.get('id') == request_id:
                # Exact received bytes, not re-serialized JSON.
                (self.root / filename).write_bytes(raw)
                return response

    def close(self):
        self.process.stdin.close()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(self.process.pid, signal.SIGTERM)
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(self.process.pid, signal.SIGKILL)
                self.process.wait(timeout=3)
        self.reader.join(timeout=3)
        self.stderr.close()
        self.sent.close()
        self.received.close()


def assertions(mode, response, records):
    errors = []
    expected_id = 'pat-loopback-' + mode
    posts = [r for r in records if r['method'] == 'POST']
    if len(posts) != 1 or posts[0]['path'] != '/api/patterns':
        errors.append('expected exactly one POST /api/patterns, got %s' % len(posts))
    if mode in ('bare', 'wrapped'):
        result = response.get('result', {})
        text = '\n'.join(c.get('text', '') for c in result.get('content', []))
        if 'error' in response or result.get('isError') or ('Created pattern: ' + expected_id) not in text:
            errors.append('missing successful persisted id')
    else:
        error = response.get('error', {})
        data = error.get('data', {})
        message = error.get('message', '')
        if data.get('outcome') != 'uncertain' or 'uncertain' not in message.lower():
            errors.append('missing uncertain error')
        if data.get('http_status') != 201:
            errors.append('missing http_status=201')
        if data.get('retry_safe') is not False:
            errors.append('missing retry_safe=false')
        reference = data.get('reconciliation_id', '')
        if mode == 'missing_id_header':
            if reference != REQUEST_ID:
                errors.append('x-request-id not preserved')
        else:
            try:
                if not reference.startswith('local-'):
                    raise ValueError('missing local prefix')
                if uuid.UUID(reference[len('local-'):]).version != 4:
                    raise ValueError('not a UUIDv4')
            except (ValueError, AttributeError):
                errors.append('missing local UUID reconciliation id')
        if 'pattern action=list' not in message or 'Do not retry' not in message:
            errors.append('missing no-retry/list-reconciliation guidance')
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin', required=True, help='explicit binary under test; no implicit PATH lookup')
    parser.add_argument('--out', required=True, help='new evidence run directory inside this loopback directory')
    parser.add_argument('--expect-version', help='refuse an unexpected baseline version before initialization')
    parser.add_argument('--netns-child', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    binary = Path(args.bin).expanduser().resolve(strict=True)
    if not binary.is_file() or not os.access(binary, os.X_OK):
        parser.error('--bin must name an executable file')
    out = Path(args.out).expanduser().resolve()
    if ROOT not in out.parents or out.exists():
        parser.error('--out must be a NEW directory inside ' + str(ROOT))
    if platform.system() == 'Linux' and not args.netns_child:
        unshare = shutil.which('unshare', path='/usr/sbin:/usr/bin:/sbin:/bin')
        if not unshare:
            parser.error('REFUSED: unshare unavailable; no host-network fallback')
        command = [unshare, '-rn', '--', sys.executable, '-I', str(Path(__file__).resolve()),
                   '--bin', str(binary), '--out', str(out), '--netns-child']
        if args.expect_version:
            command += ['--expect-version', args.expect_version]
        return subprocess.call(command, env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin',
                                             'PYTHONNOUSERSITE':'1'})
    if platform.system() == 'Linux':
        verify_linux_namespace()
    elif args.netns_child:
        parser.error('REFUSED: namespace child flag is Linux-only')
    # Never nest runtime files under protected real ~/.cas. Copy evidence only
    # after the sandboxed children exit, then remove this exact allocation.
    parent_tmp = Path(os.environ.get('TMPDIR') or tempfile.gettempdir()).resolve()
    root = Path(tempfile.mkdtemp(prefix='casd16e.', dir=parent_tmp)).resolve()
    (root / 'project').mkdir()
    results = []
    try:
        with CloudStub(root / 'http-requests.jsonl') as stub:
            env = child_env(root, stub.endpoint)
            policy = sandbox_profile(root, binary, stub.endpoint)
            profile = root / 'sandbox.sb' if policy is not None else None
            if profile is not None:
                profile.write_text(policy)
            version = guarded(binary, ['--version'], profile, root, env, 'version')
            if args.expect_version and args.expect_version not in version:
                raise RuntimeError('REFUSED unexpected binary version: ' + version)
            git = Path('/Library/Developer/CommandLineTools/usr/bin/git') if platform.system() == 'Darwin' else Path('/usr/bin/git')
            if not git.is_file():
                raise RuntimeError('REFUSED: direct Git binary unavailable; no xcrun fallback')
            guarded(git, ['-c', 'init.templateDir=', 'init', '-q'], profile, root, env, 'git-init')
            guarded(binary, ['init', '--yes', '--no-integrations'], profile, root, env, 'cas-init')
            cas = root / 'project/.cas'
            (cas / 'config.toml').write_text('[cloud]\nauto_sync = false\n[code]\nenabled = false\n[telemetry]\nenabled = false\n[worktrees]\nenabled = false\n')
            config = {'endpoint': stub.endpoint, 'token': TOKEN, 'team_auto_promote': False,
                      'factory_cloud_client_enabled': False}
            for target in (cas / 'cloud.json', root / 'home/.cas/cloud.json'):
                target.write_text(json.dumps(config))
                target.chmod(0o600)
            env['CAS_ROOT'] = str(cas)
            metadata = {'binary': str(binary), 'version': version, 'candidate_source_read': SOURCE_SHA,
                        'endpoint': validate_endpoint(stub.endpoint), 'root': str(root),
                        'isolation': ('macOS allow-default/explicit-deny sandbox; temp data; exact loopback port only'
                                      if profile else 'Linux unshare -rn; only lo; temp HOME and cleared env'),
                        'scope': 'binary-under-test versus loopback fixture; no real Cloud'}
            (root / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
            mcp = MCP(binary, profile, root, env)
            try:
                init = mcp.call(1, 'initialize', {'protocolVersion': '2024-11-05', 'capabilities': {},
                               'clientInfo': {'name': 'cas-d16e-independent-loopback', 'version': '1'}}, 'initialize.json')
                if 'error' in init:
                    raise RuntimeError('initialize failed')
                mcp.send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
                for index, mode in enumerate(MODES):
                    with stub.lock:
                        stub.mode = mode
                        before = len(stub.requests)
                    response = mcp.call(10 + index, 'tools/call', {'name': 'pattern', 'arguments': {
                        'action': 'create', 'content': 'Public loopback fixture ' + mode,
                        'category': 'general', 'priority': 1, 'tags': 'cas-d16e-loopback'}}, mode + '-response.json')
                    with stub.lock:
                        records = list(stub.requests[before:])
                    errors = assertions(mode, response, records)
                    listed = mcp.call(20 + index, 'tools/call', {'name': 'pattern', 'arguments': {
                        'action': 'list'}}, mode + '-list-response.json')
                    list_text = json.dumps(listed)
                    if 'pat-loopback-' + mode not in list_text or 'error' in listed:
                        errors.append('list reconciliation did not surface persisted id')
                    outcome = {'mode': mode, 'pass': not errors, 'errors': errors,
                               'post_count': sum(r['method'] == 'POST' for r in records),
                               'response': response}
                    results.append(outcome)
                    print(('%s %s: ' % ('PASS' if not errors else 'FAIL', mode)) +
                          ('; '.join(errors) if errors else 'persisted id/reconciliation/no-retry contract'), flush=True)
            finally:
                mcp.close()
            # Count after shutdown too: no deferred retry may escape the per-call count.
            with stub.lock:
                posts = [r for r in stub.requests if r['method'] == 'POST']
            if len(posts) != len(MODES):
                raise RuntimeError('expected exactly five total POSTs, got %s' % len(posts))
            (root / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
            print('SUMMARY %s/%s PASS; %s POSTs; real MCP binary %s; loopback Cloud fixture' %
                  (sum(r['pass'] for r in results), len(results), len(posts), version), flush=True)
            return 0 if all(r['pass'] for r in results) else 1
    except Exception as error:
        (root / 'driver-error.txt').write_text(str(error) + '\n')
        for mode in MODES[len(results):]:
            print('FAIL %s: NOT EXERCISED; %s' % (mode, error), flush=True)
        print('SUMMARY %s/%s PASS; remaining modes NOT EXERCISED; DRIVER ERROR: %s' %
              (sum(r['pass'] for r in results), len(MODES), error), flush=True)
        return 2
    finally:
        # MCP.close() above has exited/reaped serve before this evidence copy.
        out.mkdir(mode=0o700, parents=True)
        for source in root.iterdir():
            if source.is_file():
                shutil.copyfile(source, out / source.name)
                (out / source.name).chmod(0o600)
        if root.parent == parent_tmp and root.name.startswith('casd16e.') and not root.is_symlink():
            shutil.rmtree(root)
            (out / 'cleanup.txt').write_text('Removed exact temporary root: ' + str(root) + '\n')
        else:
            raise RuntimeError('REFUSED: unexpected temporary root; retained for operator review')


if __name__ == '__main__':
    sys.exit(main())
