#!/bin/bash
set -euo pipefail
umask 077
script_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
exec /usr/bin/env python3 -I "$script_dir/driver.py" "$@"
